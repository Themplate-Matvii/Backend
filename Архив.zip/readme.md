# **Template Backend**

Модульная, масштабируемая архитектура для **SaaS/Marketplace** проектов на
**Node.js + TypeScript + Express + MongoDB**,
поддерживает:

* подписки + одноразовые покупки,
* биллинг и синхронизацию с Stripe,
* систему ролей и permissions,
* модульную структуру, позволяющую легко расширять проект.

---

# 📂 **Архитектура проекта**

Проект построен по принципу **Domain-Driven Modules** — каждый домен имеет свои:

* модели,
* сервисы,
* контроллеры,
* роуты,
* бизнес-логику.

Ниже — актуальное дерево модулей:

```
src/
  modules/
    billing/
      pricing/
      payments/
        providers/
          base/
          stripe/
      subscriptions/
      types/

    bonus/
    core/
    landings/

    user/
      index/
      auth/
      settings/
      account/

    communication/
      feedback/
      email/

    assets/
      media/

    analytics/
      business/
      traffic/
```

---

# 🧩 **Описание модулей**

## 📦 **billing/**

Центральный модуль для всех операций, связанных с подписками и платежами.

### **billing/pricing/**

Отвечает за:

* объединённый список продуктов:

  * **подписки (`plans`)**
  * **одноразовые покупки (`oneTimeProducts`)**
* получение данных для фронта
* склейку данных: константы + провайдер (Stripe)

### **billing/payments/**

Отвечает за:

* создание checkout-сессий в Stripe
* регистрацию успешных/неуспешных оплат
* хранение истории платежей

**Структура провайдеров:**

```
payments/
  providers/
    base/      — базовый интерфейс всех платежных провайдеров
    stripe/    — реализация Stripe
```

### **billing/subscriptions/**

Ответственность:

* хранение подписки пользователя
* обновление статуса (active, canceled, expired)
* интеграция с платежными webhook

### **billing/types/**

Общие enum’ы и типы:

* `PaymentMode`
* `ProviderWebhookEventType`
* `BonusSourceType`
* billing модели

---

## 🎁 **bonus/**

Отвечает за бонусы, выдаваемые:

* при покупке подписки
* при покупке one-time товара

---

## 🧩 **core/**

Системные модули, утилиты, middleware, ядро проекта.

---

## 📰 **landings/**

CRUD для генерации, хранения и управления лендингами.

---

## 👤 **user/**

Модуль пользователя разделён на три части:

```
    user/
      index/      — профиль пользователя, /me, обновление данных
      auth/       — регистрация, логин, refresh tokens, OAuth
      settings/   — пользовательские настройки (тема, язык, уведомления)
      account/    — управление аккаунтом, провайдеры, email flows, удаление
```

---

## 💬 **communication/**

Работа с коммуникацией:

```
communication/
  feedback/   — отзывы, NPS, формы обратной связи
  email/      — email-рассылки (одиночная и массовая)
```

---

## 🗂 **assets/**

Хранение пользовательских медиа:

```
assets/
  media/
```

---

## 🧰 **Миграции**

* `src/scripts/migrateEmailProviders.ts` — добавляет `provider=email` и `AuthIdentity` для существующих email-аккаунтов.

---

## 📊 **analytics/**

Две ключевые подсистемы:

```
analytics/
  business/   — доход, MRR, ARPU, конверсии
  traffic/    — просмотры, переходы, события пользователя
```

---

# ⚙️ **Технический стек**

* **Node.js + TypeScript**
* **Express**
* **MongoDB + Mongoose**
* **Stripe API** (подписки, одноразовые покупки)
* JWT-аутентификация
* Role + Permissions система
* i18n локализация

---

# 🔄 **Биллинг: поток данных**

### 1) Синхронизация продуктов с Stripe

```
constants (plans + oneTimeProducts)
        ↓
pricingService
        ↓
stripeProvider.sync()
        ↓
BillingProductModel
```

---

### 2) Создание checkout-сессии

```
paymentService → createCheckoutSession(planKey/productKey)
        ↓
stripeProvider → checkout.sessions.create()
```

---

### 3) Webhook Stripe

```
stripe → webhook
        ↓
stripeProvider.handleWebhook()
        ↓
paymentModel
subscriptionService
bonusService
```

---

# 🔐 **Авторизация**

Модуль `user/auth` включает:

* регистрацию
* логин
* refresh-сессии
* logout
* OAuth-провайдеры (Google, Apple)
* ограничения прав через middleware `checkPermission`

---

# 📡 Пример ответа `/api/me`

```json
{
  "user": {
    "id": "123",
    "email": "test@example.com",
    "role": "user",
    "plan": "basic"
  },
  "permissions": {
    "landings": {
      "create": true,
      "own": { "view": true, "edit": true, "delete": true },
      "any": { "view": false, "edit": false, "delete": false }
    },
    "feedback": { "view": true },
    "email": { "one": false, "broadcast": false }
  }
}
```

---

# 🧱 Готово к использованию

Архитектура подходит для:

* SaaS-сервисов
* no-code / low-code платформ
* маркетплейсов
* AI-приложений
* 
