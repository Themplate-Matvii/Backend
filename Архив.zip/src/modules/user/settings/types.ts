export enum ThemeEnum {
  LIGHT = "light",
  DARK = "dark",
  SYSTEM = "system",
}