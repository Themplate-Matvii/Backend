export type MsString = `${number}${"ms" | "s" | "m" | "h" | "d" | "w" | "y"}`;
